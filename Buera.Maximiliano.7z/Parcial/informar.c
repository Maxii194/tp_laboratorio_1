#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#include "utn.h"
