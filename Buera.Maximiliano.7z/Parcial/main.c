#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "cliente.h"
#include "aviso.h"
#include "utn.h"
#include "informar.h"
#define QTY 100
#define LEN_AVISOS 1000

int main()
{
    Cliente arrayClientes[QTY];
    Aviso arrayAvisos[LEN_AVISOS];
    int menu;
    int auxiliarId;

    cliente_init(arrayClientes,QTY);
    //cont_init(contrataciones,LEN_AVISOS);


    cliente_altaForzada(arrayClientes,QTY,"Pablo","Belgrano","20132135");

    do
    {
        getValidInt("\n\n1.Alta\n2.Baja\n3.Modificar\n4.Mostrar\n5.Ordenar\n6.Mostrar Debug\n7.Contratar\n9.Salir\n","\nNo valida\n",&menu,1,9,1);
        switch(menu)
        {
            case 1:
                cliente_alta(arrayClientes,QTY);
                break;
            case 2:
                getValidInt("ID?","\nNumero invalido\n",&auxiliarId,0,200,2);
                cliente_baja(arrayClientes,QTY,auxiliarId);
                break;
            case 3:
                getValidInt("ID?","\nNumero invalido\n",&auxiliarId,0,200,2);
                cliente_modificacion(arrayClientes,QTY,auxiliarId);
                break;
            case 4:
                cliente_mostrar(arrayClientes,QTY);
                break;
            case 5:
                cliente_ordenar(arrayClientes,QTY,0);
                break;
            case 6:
                cliente_mostrarDebug(arrayClientes,QTY);
                break;
            case 7:
                getValidInt("ID?","\nNumero invalido\n",&auxiliarId,0,200,2);
                aviso_alta(arrayAvisos,arrayClientes,LEN_AVISOS);
                break;
        }

    }while(menu != 9);

    return 0;
}
