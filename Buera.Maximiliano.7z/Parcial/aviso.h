#ifndef AVISO_H_INCLUDED
#define AVISO_H_INCLUDED
typedef struct
{
    char textoAviso[64];
    int numeroRubro;
    //------------
    int estado;
    int idAviso;
    int idCliente;
}Aviso;
#endif // AVISO_H_INCLUDED

int aviso_init(Aviso* array,int limite);
int aviso_buscarPorId(Aviso* array,int limite, int id);
//int aviso_pausar(Aviso* array,Cliente* arrayCliente, int limite, int id);

int aviso_mostrar(Aviso* array,int limite);
int aviso_mostrarDebug(Aviso* array,int limite);
//int aviso_alta(Aviso* array,Cliente* arrayClientes,int limite);
int aviso_modificacion(Aviso* array,int limite, int id);
int aviso_ordenar(Aviso* array,int limite, int orden);

int aviso_altaForzada(Aviso* array,int limite,char* nombre,char* apellido, char* cuit);
