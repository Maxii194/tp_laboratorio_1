#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "aviso.h"
#include "utn.h"
#include "cliente.h"
#define QTY 100
#define LEN_AVISOS 1000
#define OCUPADO 0
#define LIBRE 1
#define PAUSADA 0
#define ACTIVA 1
#define NO_ACTIVA -1


static int buscarLugarLibre(Aviso* array,int limite);
//static int proximoId();

int aviso_init(Aviso* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            strcpy(array[i].textoAviso,"");
            array[i].numeroRubro = '\0';
            array[i].idAviso = '\0';
            array[i].idCliente = '\0';
            array[i].estado = NO_ACTIVA;
        }
    }
    return retorno;
}

int aviso_buscarPorId(Aviso* array,int limite, int id)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(array[i].estado == ACTIVA && array[i].idAviso == id)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}

int aviso_pausar(Aviso* array,Cliente* arrayCliente,int limite, int id)
{

    int retorno = -1;
    int indice;
    indice = cliente_buscarPorId(arrayCliente,limite,id);
    if(indice >= 0)
    {
        retorno = 0;
        printf("%s - %s - %s",arrayCliente[indice].nombre,arrayCliente[indice].apellido,arrayCliente[indice].cuit);
        array[indice].estado = PAUSADA;
    }
    return retorno;
}

int aviso_reaunadar(Aviso* array,Cliente* arrayCliente,int limite, int id)
{

    int retorno = -1;
    int indice;
    indice = cliente_buscarPorId(arrayCliente,limite,id);
    if(indice >= 0)
    {
        retorno = 0;
        array[indice].estado = ACTIVA;
        printf("%s - %s - %s",arrayCliente[indice].nombre,arrayCliente[indice].apellido,arrayCliente[indice].cuit);
    }
    return retorno;
}

int aviso_mostrar(Aviso* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(array[i].estado == ACTIVA)
            {
               printf("\n[RELEASE] %s - %d - %d - %d - %d",array[i].textoAviso,array[i].numeroRubro,array[i].idAviso,array[i].idCliente,array[i].estado);
            }
        }
    }
    return retorno;
}

int aviso_mostrarDebug(Aviso* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            printf("\n[RELEASE] %s - %d - %d - %d - %d",array[i].textoAviso,array[i].numeroRubro,array[i].idAviso,array[i].idCliente,array[i].estado);
        }
    }
    return retorno;
}


int aviso_alta(Aviso* array,Cliente* arrayClientes,int limite)
{
    int retorno = -1;
    char textoAviso[64];
    int numeroRubro;
    int id;
    int indice;

    if(limite > 0 && array != NULL)
    {
        retorno = -2;
        indice = buscarLugarLibre(array,limite);
        if(indice >= 0)
        {
            retorno = -3;

            if(cliente_buscarPorId(arrayClientes,limite,id) == id){

                if(!getValidInt("Numero Rubro?","\nNumero invalido\n",&numeroRubro,0,LEN_AVISOS,2))
                {
                    if(!getValidString("Texto Aviso?","Error","Overflow", textoAviso,64,2)){

                        retorno = 0;
                        strcpy(array[indice].textoAviso,textoAviso);
                        array[indice].numeroRubro = numeroRubro;
                        array[indice].idAviso = id;
                        array[indice].estado = ACTIVA;
                    }
                }
            }
        }
    }
    return retorno;
}


/*int aviso_modificacion(Aviso* array,int limite, int id)
{
    int retorno = -1;
    int indice;
    char nombre[50];
    char apellido[50];
    char cuit[20];
    indice = aviso_buscarPorId(array,limite,id);
    if(indice >= 0)
    {
        retorno = -2;
        if(!getValidString("Nombre?","Error\n","Overflow", nombre,50,2))
        {
            if(!getValidString("Apellido?","Error\n","Overflow", nombre,50,2))
            {
                if(!getValidString("Cuit?","Error\n","Overflow", nombre,20,2)){

                    retorno = 0;
                    strcpy(array[indice].nombre,nombre);
                    strcpy(array[indice].apellido,apellido);
                    strcpy(array[indice].cuit,cuit);
                }
            }
        }
    }
    return retorno;
}*/


static int buscarLugarLibre(Aviso* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(array[i].estado == NO_ACTIVA)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}


/*static int proximoId()
{
    static int ultimoId = -1;
    ultimoId++;
    return ultimoId;
}*/



/*int aviso_ordenar(Aviso* array,int limite, int orden)
{
    int retorno = -1;
    int flagSwap;
    int i;
    Aviso auxiliar;

    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        do
        {
            flagSwap = 0;
            for(i=0;i<limite-1;i++)
            {
                    if(array[i].estado == ACTIVA && array[i+1].estado == ACTIVA )
                    {
                        if((strcmp(array[i].idAviso,array[i+1].idAviso) > 0 && !orden) || (strcmp(array[i].idAviso,array[i+1].idAviso) < 0 && orden)) //<------------
                        {
                            auxiliar = array[i];
                            array[i] = array[i+1];
                            array[i+1] = auxiliar;
                            flagSwap = 1;
                        }
                    }
            }
        }while(flagSwap);
    }

    return retorno;
}
*/

/*int aviso_altaForzada(Aviso* array,int limite,char* textoAviso,int* numeroRubro, int* id)
{
    int retorno = -1;
    int i;

    if(limite > 0 && array != NULL)
    {
        i = buscarLugarLibre(array,limite);
        if(i >= 0)
        {
            retorno = 0;
            strcpy(array[i].textoAviso,textoAviso);
            array[i].numeroRubro = numeroRubro;
            //------------------------------
            //------------------------------
            array[i].idAviso = proximoId();
            array[i].estado = ACTIVA;
        }
        retorno = 0;
    }
    return retorno;
}*/
